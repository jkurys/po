public class Rational {
    private int numerator;
    private int denominator;
    public Rational(int numerator, int denominator) {
        if (LCM(numerator, denominator) > 1) {
            int LCM = LCM(numerator, denominator);
            numerator /= LCM;
            denominator /= LCM;
        }
        this.numerator = numerator;
        this.denominator = denominator;
    }
    public Rational(int n) {
        this.numerator = n;
        this.denominator = 1;
    }
    public Rational zero() {
        return new Rational(0);
    }
    public Rational one() {
        return new Rational(1);
    }
    public int numerator() {
        return this.numerator;
    }
    public int denominator() {
        return this.denominator;
    }
    private int LCM(int number1, int number2) { //NWW
        return number1 * number2 / GCD(number1, number2);
    }
    private int GCD(int number1, int number2) { //NWD
        if (number1 < number2) {
            int tmp = number2;
            number2 = number1;
            number1 = tmp;
        }
        while (number2 != 0) {
            number1 %= number2;
            int tmp = number2;
            number2 = number1;
            number1 = tmp;
        }
        return number1;
    }
    public Rational add(Rational number) {
        int newNumerator = this.numerator * LCM(this.denominator, number.denominator()) / this.denominator
                + number.numerator() * LCM(this.denominator, number.denominator()) / number.denominator;
        int newDenominator = LCM(this.denominator, number.denominator());
        if (LCM(newNumerator, newDenominator) > 1) {
            int LCM = LCM(newNumerator, newDenominator);
            newNumerator /= LCM;
            newDenominator /= LCM;
        }
        return new Rational(newNumerator, newDenominator);
    }

    public Rational substract(Rational number) {
        return add(number.opposite());
    }

    public Rational multiply(Rational number) {
        int newNumerator = this.numerator * number.numerator();
        int newDenominator = this.denominator * number.denominator();
        if (LCM(newNumerator, newDenominator) > 1) {
            int LCM = LCM(newNumerator, newDenominator);
            newNumerator /= LCM;
            newDenominator /= LCM;
        }
        return new Rational(newNumerator, newDenominator);
    }

    public Rational divide(Rational number) {
        return multiply(number.inverse());
    }

    public Rational inverse() {
        return one().divide(this);
    }

    public Rational opposite() {
        return zero().substract(this);
    }

    public int sign() {
        if (this.numerator == 0) {
            return 0;
        }
        else if (this.numerator > 0) {
            return 1;
        }
        else {
            return -1;
        }
    }

    public int compare(Rational x) {
        Rational wynik = substract(x);
        return wynik.sign();
    }

    @Override
    public String toString() {
        String s = numerator + "/" + denominator;
        return s;
    }
}
