public class Main {
    static public void main(String args[]) {
        Rational half = new Rational(2,4);
        assert(half.denominator() == 2);
        assert(half.multiply(new Rational(2)).denominator() == 1);
        assert(half.inverse().numerator() == 2);
        assert(half.add(new Rational(1,6)).denominator() == 3);
    }
}
