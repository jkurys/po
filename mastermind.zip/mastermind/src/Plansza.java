public class Plansza
{
    private Kod[] zgadnięcia;
    private Ocena[] oceny;
    private int ilośćTur;
    private int maksymalnaIlośćTur;
    public Plansza(int maksymalnaIlośćTur) {
        this.maksymalnaIlośćTur = maksymalnaIlośćTur;
        zgadnięcia = new Kod [maksymalnaIlośćTur];
        oceny = new Ocena [maksymalnaIlośćTur];
        ilośćTur = 0;
    }
    public void dodajZgadnięcie(Kod zgadnięcie, Ocena ocena) {
        zgadnięcia[ilośćTur] = zgadnięcie;
        oceny[ilośćTur] = ocena;
        ilośćTur++;
    }
    public int któraTura() {
        return ilośćTur;
    }
    public Kod dajKod(int indeks) {
        return zgadnięcia[indeks];
    }
    public Ocena dajOcenę(int indeks) {
        return oceny[indeks];
    }
}


