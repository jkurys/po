import java.util.Random;

public class GraczZgadujący
{
    private boolean czyMaszyna;
    private Random losowanie = new Random();
    GraczZgadujący(boolean czyMaszyna) {
        this.czyMaszyna = czyMaszyna;
    }
    public Kod zgaduj() {
        if (czyMaszyna == true) {
            Pionek[] pionki = new Pionek[4];
            for (int i = 0; i < 4; ++i) {
                pionki[i] = new Pionek(losowanie.nextInt(6));
            }
            return new Kod(pionki);
        }
        else {
            Kod kod = null;
            while (kod == null) {
                kod = GraficznyInterfejs.poprośOZgadnięcie();
            }
            return kod;
        }
    }
}