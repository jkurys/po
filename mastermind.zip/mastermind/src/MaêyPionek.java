public class MałyPionek
{
    private final int poprawnie;
    public MałyPionek (int poprawnie) {
        this.poprawnie = poprawnie;
    }
    public int poprawnie() {
        return poprawnie;
    }
    @Override
    public String toString() {
        if (poprawnie == 2) return "Miejsce i kolor OK";
        else if (poprawnie == 1) return "Kolor OK";
        else return "Nie OK";
    }

}