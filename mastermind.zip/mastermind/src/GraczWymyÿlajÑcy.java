import java.util.Random;

public class GraczWymyślający
{
    private Random losowanie = new Random();
    private Kod kod;
    private boolean czyMaszyna;

    GraczWymyślający(boolean czyMaszyna) {
        this.czyMaszyna = czyMaszyna;
    }
    public Kod wymyślKod()
    {
        if (czyMaszyna == true) {
            Pionek[] pionki = new Pionek[4];
            for (int i = 0; i < 4; ++i) {
                pionki[i] = new Pionek(losowanie.nextInt(6));
            }
            this.kod = new Kod(pionki);
            return this.kod;
        }
        else {
            Kod kod = null;
            while (kod == null) {
                kod = GraficznyInterfejs.poprośOKod();
            }
            return kod;
        }
    }

    public Ocena dajOcenę(Kod zgadnięcie)
    {
        if (czyMaszyna == true) {
            Pionek[] zgadywane = zgadnięcie.dajKod();
            Pionek[] zakodowane = kod.dajKod();
            MałyPionek[] małePionki = new MałyPionek[4];
            for (int i = 0; i < 4; i++) {
                if (zgadywane[i].kolor() == zakodowane[i].kolor()) {
                    małePionki[i] = new MałyPionek(2);
                } else {
                    int j;
                    for (j = 0; j < 4; j++) {
                        if (zgadywane[i].kolor() == zakodowane[j].kolor()) {
                            break;
                        }
                    }
                    if (j < 4) {
                        małePionki[i] = new MałyPionek(1);
                    } else {
                        małePionki[i] = new MałyPionek(0);
                    }
                }

            }
            return new Ocena(małePionki);
        }
        else {
            Ocena ocena = null;
            while (ocena == null) {
                ocena = GraficznyInterfejs.poprośOOcenę(zgadnięcie);
            }
            return ocena;
        }
    }

}