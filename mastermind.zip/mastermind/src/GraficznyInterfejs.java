import java.util.Scanner;

public class GraficznyInterfejs {
    public static Kod poprośOKod() {
        System.out.println("Podaj swój kod (liczby z przedziału 0 - 5):");
        Scanner scanner = new Scanner(System.in);
        Pionek[] kolory = new Pionek[4];
        for (int i = 0; i < 4; i++) {
            if (scanner.hasNext()) {
                try {
                    kolory[i] = new Pionek(scanner.nextInt());
                }
                catch (AssertionError err) {
                    System.out.println("Złe dane!");
                }
            }
        }
        Kod kod = null;
        try {
            kod = new Kod(kolory);
        }
        catch (AssertionError err) {
            System.out.println("Złe dane!");
        }
        return kod;
    }
    public static Kod poprośOZgadnięcie() {
        System.out.println("Zgadnij kod:");
        Scanner scanner = new Scanner(System.in);
        Pionek[] kolory = new Pionek[4];
        for (int i = 0; i < 4; i++) {
            if (scanner.hasNext()) {
                try {
                    kolory[i] = new Pionek(scanner.nextInt());
                }
                catch (AssertionError err) {
                    System.out.println("Złe dane!");
                }
            }
        }
        Kod kod = null;
        try {
            kod = new Kod(kolory);
        }
        catch (AssertionError err) {
            System.out.println("Złe dane!");
        }
        return kod;
    }
    public static Ocena poprośOOcenę(Kod zgadnięcie) {
        System.out.println("Oto zgadnięty kod:");
        System.out.println(zgadnięcie.toString());
        System.out.println("Podaj swoją ocenę każdego pola(2 jeśli poprawnie, 1 jeśli dobry kolor, 0 jeśli zły kolor):");
        Scanner scanner = new Scanner(System.in);
        MałyPionek[] pionki = new MałyPionek[4];
        for (int i = 0; i < 4; i++) {
            if (scanner.hasNext()) {
                try {
                    pionki[i] = new MałyPionek(scanner.nextInt());
                }
                catch (AssertionError err) {
                    System.out.println("Złe dane!");
                }
            }
        }
        Ocena ocena = null;
        try {
            ocena = new Ocena(pionki);
        }
        catch (AssertionError err) {
            System.out.println("Złe dane!");
        }
        return ocena;
    }
    public static void wyświetlPlanszę(Plansza plansza) {
        int ilośćTur = plansza.któraTura();
        for (int i = 0; i < ilośćTur; i++) {
            Kod kod = plansza.dajKod(i);
            Ocena ocena = plansza.dajOcenę(i);
            System.out.println(kod.toString());
            System.out.println(ocena.toString());
        }
    }
    public static Gra PoprośOWybórGry() {
        Character c = 'a';
        Scanner scanner = new Scanner(System.in);
        while (!c.equals('Z') && !c.equals('z') && !c.equals('K') && !c.equals('k')) {
            System.out.println("Wybierz, czy chcesz być graczem kodującym, czy zgadującym.");
            String s = scanner.nextLine();
            c = s.charAt(0);
        }
        Gra gra = null;
        if (c.equals('Z') || c.equals('z')) {
            System.out.println("Ile tur chcesz grać?");
            int ilośćTur = scanner.nextInt();
            gra = new Gra(new GraczWymyślający(true), new GraczZgadujący(false), ilośćTur);
        }
        else if (c.equals('K') || c.equals('k')) {
            System.out.println("Ile tur chcesz grać?");
            int ilośćTur = scanner.nextInt();
            gra = new Gra(new GraczWymyślający(false), new GraczZgadujący(true), ilośćTur);
        }
        return gra;
    }
    public static void zgadniętyKod() {
        System.out.println("Kod został zgadnięty!");
    }

    public static void zakończenieGry() {
        System.out.println("Gra została zakończona.");
    }
}