import java.util.Scanner;

public class Symulacja {
    public static void main(String[] args) {
        Gra gra = GraficznyInterfejs.PoprośOWybórGry();
        gra.przeprowadźGrę();
    }
}
