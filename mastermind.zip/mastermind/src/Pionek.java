public class Pionek
{
    private final int kolor;
    public Pionek (int kolor) {
        if (kolor < 0 || kolor > 5) throw new AssertionError();
        this.kolor = kolor;
    }
    public int kolor() {
        return kolor;
    }
}