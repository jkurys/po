public class Kod
{
    private final Pionek[] pionki;
    public Kod (Pionek[] pionki) {
        if (pionki.length != 4) throw new AssertionError();
        this.pionki = pionki;
    }
    public Pionek[] dajKod () {
        return pionki;
    }
    @Override
    public String toString() {
        String s = "";
        for (int i = 0; i < 4; i++) {
            s += pionki[i].kolor() + " ";
        }
        return s;
    }
}