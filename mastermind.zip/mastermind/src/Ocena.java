public class Ocena
{
    private final MałyPionek[] małePionki;
    public Ocena (MałyPionek[] małePionki) {
        if (małePionki.length > 4) throw new AssertionError();
        this.małePionki = małePionki;
    }
    @Override
    public String toString() {
        String s = "";
        for (int i = 0; i < 4; i++) {
            s += (i + 1) + ". " + małePionki[i].toString() + " ";
        }
        return s;
    }
    @Override
    public boolean equals(Object obiekt) {
        if (this == obiekt) {
            return true;
        }
        if (obiekt == null) {
            return false;
        }
        if (getClass() != obiekt.getClass()) {
            return false;
        }
        Ocena ocena = (Ocena)obiekt;
        for (int i = 0; i < 4; i++) {
            if (ocena.małePionki[i].poprawnie() != this.małePionki[i].poprawnie()) {
                return false;
            }
        }
        return true;
    }
}