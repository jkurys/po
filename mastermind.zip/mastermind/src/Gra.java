public class Gra {
    private final GraczWymyślający kodujący;
    private final GraczZgadujący zgadujący;
    private Plansza plansza;
    private int ilośćTur;
    public Gra(GraczWymyślający kodujący, GraczZgadujący zgadujący, int ilośćTur) {
        this.kodujący = kodujący;
        this.zgadujący = zgadujący;
        this.ilośćTur = ilośćTur;
        this.plansza = new Plansza(ilośćTur);
    }
    public void przeprowadźGrę() {
        kodujący.wymyślKod();
        MałyPionek[] dobrePionki = new MałyPionek[4];
        for (int i = 0; i < 4; i++) {
            dobrePionki[i] = new MałyPionek(2);
        }
        Ocena dobrze = new Ocena(dobrePionki);
        for (int i = 0; i < ilośćTur; i++) {
            Kod kod = zgadujący.zgaduj();
            Ocena ocena = kodujący.dajOcenę(kod);
            plansza.dodajZgadnięcie(kod, ocena);
            GraficznyInterfejs.wyświetlPlanszę(plansza);
            if (ocena.equals(dobrze)) {
                GraficznyInterfejs.zgadniętyKod();
                break;
            }
        }
        GraficznyInterfejs.zakończenieGry();
    }
}
