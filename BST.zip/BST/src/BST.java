public class BST <T extends Comparable <T>> {
    private class Węzeł {
        Węzeł lewy;
        Węzeł prawy;
        T wartość;
        public Węzeł (T wartość) {
            this.wartość = wartość;
        }
        public void dodaj(T element) {
            if (element.compareTo(wartość) == -1) {
                if (lewy != null) {
                    lewy.dodaj(element);
                }
                else {
                    lewy = new Węzeł(element);
                }
            }
            else if (element.compareTo(wartość) == 1) {
                if (prawy != null) {
                    prawy.dodaj(element);
                }
                else {
                    prawy = new Węzeł(element);
                }
            }
        }
    }
    Węzeł korzeń = null;

    public boolean czyPusty() {
        return (korzeń == null);
    }
    public void dodaj(T element) {
        korzeń.dodaj(element);
    }
}
