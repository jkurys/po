import java.util.ArrayList;

public class Sito {
    public ArrayList<Integer> przesiej(int dokąd) {
        boolean[] czyPierwsza = new boolean[dokąd];
        ArrayList<Integer> wynik = new ArrayList<>();
        for (int i = 0; i <= dokąd; i++) {
            czyPierwsza[i] = true;
        }
        for (int i = 2; i <= dokąd; i++) {
            if (czyPierwsza[i] == true) {
                wynik.add(i);
            }
            for (int j = 2; j <= dokąd / i; j++) {
                czyPierwsza[i * j] = false;
            }
        }
        return wynik;
    }
}
