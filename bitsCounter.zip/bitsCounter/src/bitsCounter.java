public class bitsCounter {
    private static int howManyBitsForAPowerOfTwo(int powerOfTwo) {
        if (powerOfTwo > 2) {
            return 2 * howManyBitsForAPowerOfTwo(powerOfTwo/2) + powerOfTwo/2 - 1;
        }
        else if (powerOfTwo == 2){
            return 2;
        }
        else {
            return 1;
        }
    }

    public static int getBits (int n) {
        int result = 0;
        int powerOfTwo = 1;
        while (powerOfTwo * 2 <= n) {
            powerOfTwo *= 2;
        }
        while (n > 0) {
            result += howManyBitsForAPowerOfTwo(powerOfTwo) + n - powerOfTwo;
            n -= powerOfTwo;
            while (powerOfTwo > n) {
                powerOfTwo /= 2;
            }
        }
        return result;
    }
}