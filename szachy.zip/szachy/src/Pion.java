import java.util.ArrayList;

public class Pion extends Bierka {
    public Pion(Gracz gracz, Współrzędne współrzędne) {
        super(gracz, współrzędne);
    }

    @Override
    public String toString() {
        if (gracz.kolor() == true) {
            return "P";
        }
        else {
            return "p";
        }
    }

    @Override
    public boolean czyMożnaRuszyć(InterfejsPlanszy plansza) {
        Współrzędne tymczasowe = new Współrzędne(współrzędne.pion(), współrzędne.poziom());
        if (gracz.kolor() == true) {
            tymczasowe.zmieńPion(1);
        }
        else {
            tymczasowe.zmieńPion(-1);
        }
        if (plansza.czyZajęte(tymczasowe) == 0) {
            return true;
        }
        tymczasowe.zmieńPoziom(1);
        if (plansza.czyPrzeciwnik(tymczasowe, gracz) == 1) {
            return true;
        }
        tymczasowe.zmieńPoziom(-2);
        if (plansza.czyPrzeciwnik(tymczasowe, gracz) == 1) {
            return true;
        }
        return false;
    }

    @Override
    public Współrzędne[] możliweRuchy(InterfejsPlanszy plansza) {
        ArrayList<Współrzędne> możliweRuchy = new ArrayList<>();
        Współrzędne tymczasowe = new Współrzędne(współrzędne.pion(), współrzędne.poziom());
        if (gracz.kolor() == true) {
            tymczasowe.zmieńPion(1);
        }
        else {
            tymczasowe.zmieńPion(-1);
        }
        if (plansza.czyZajęte(tymczasowe) == 0) {
            Współrzędne kopia = new Współrzędne(tymczasowe.pion(), tymczasowe.poziom());
            możliweRuchy.add(kopia);
        }
        tymczasowe.zmieńPoziom(1);
        if (plansza.czyPrzeciwnik(tymczasowe, gracz) == 1) {
            Współrzędne kopia = new Współrzędne(tymczasowe.pion(), tymczasowe.poziom());
            możliweRuchy.add(kopia);
        }
        tymczasowe.zmieńPoziom(-2);
        if (plansza.czyPrzeciwnik(tymczasowe, gracz) == 1) {
            Współrzędne kopia = new Współrzędne(tymczasowe.pion(), tymczasowe.poziom());
            możliweRuchy.add(kopia);
        }
        Współrzędne[] wynik = new Współrzędne[możliweRuchy.size()];
        return możliweRuchy.toArray(wynik);
    }

}
