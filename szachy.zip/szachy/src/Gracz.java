import java.util.ArrayList;
import java.util.Random;

public class Gracz {
    private boolean kolor;
    public Gracz(boolean kolor) {
        this.kolor = kolor;
    }
    public boolean kolor() {
        return kolor;
    }
    public boolean wykonajRuch(InterfejsPlanszy plansza) {
        ArrayList<Bierka> bierkiZRuchem = new ArrayList<>();
        ArrayList<Bierka> bierki = plansza.dajBierki(this);
        for (int i = 0; i < bierki.size(); i++) {
            if (bierki.get(i).czyMożnaRuszyć(plansza) == true) {
                bierkiZRuchem.add(bierki.get(i));
            }
        }
        if (bierkiZRuchem.size() == 0) {
            return true;
        }
        Random random = new Random();
        int wynikowyIndeks = random.nextInt(bierkiZRuchem.size());
        Bierka bierka = bierkiZRuchem.get(wynikowyIndeks);
        String s = "";
        if (kolor == true) {
            s += "Biały ";
        }
        else {
            s += "Czarny ";
        }
        switch (bierka.toString()) {
            case "K":
            case "k":
                s += "król ";
                break;
            case "H":
            case "h":
                s += "hetman ";
                break;
            case "G":
            case "g":
                s += "goniec ";
                break;
            case "S":
            case "s":
                s += "skoczek ";
                break;
            case "W":
            case "w":
                s += "wieża ";
                break;
            case "P":
            case "p":
                s += "pion ";
                break;
        }
        s += "z ";
        switch (bierka.współrzędne().poziom()) {
            case 0:
                s += "A";
                break;
            case 1:
                s += "B";
                break;
            case 2:
                s += "C";
                break;
            case 3:
                s += "D";
                break;
            case 4:
                s += "E";
                break;
            case 5:
                s += "F";
                break;
            case 6:
                s += "G";
                break;
            case 7:
                s += "H";
                break;
        }
        s += "" + (bierka.współrzędne().pion() + 1) + " na ";
        boolean wynik = bierka.wykonajRuch(plansza);
        switch (bierka.współrzędne().poziom()) {
            case 0:
                s += "A";
                break;
            case 1:
                s += "B";
                break;
            case 2:
                s += "C";
                break;
            case 3:
                s += "D";
                break;
            case 4:
                s += "E";
                break;
            case 5:
                s += "F";
                break;
            case 6:
                s += "G";
                break;
            case 7:
                s += "H";
                break;
        }
        s += "" + (bierka.współrzędne().pion() + 1) + "";
        System.out.println(s);
        return wynik;
    }
}
