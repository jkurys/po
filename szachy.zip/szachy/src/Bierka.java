import java.util.Random;

abstract public class Bierka {
    public Bierka(Gracz gracz, Współrzędne współrzędne) {
        this.gracz = gracz;
        this.współrzędne = współrzędne;
    }
    protected Gracz gracz;
    protected Współrzędne współrzędne;
    public Współrzędne współrzędne() {
        return współrzędne;
    }
    public boolean wykonajRuch(InterfejsPlanszy plansza) {
        Random random = new Random();
        Współrzędne[] możliweRuchy = możliweRuchy(plansza);
        int wynikowyIndeks = random.nextInt(możliweRuchy.length);
        Współrzędne wynikowePole = możliweRuchy[wynikowyIndeks];
        plansza.zmieńPole(this, wynikowePole);
        if (plansza.czyKról(wynikowePole, gracz) == true) {
            return true;
        }
        return false;
    }

    @Override
    abstract public String toString();
    abstract public boolean czyMożnaRuszyć(InterfejsPlanszy plansza);
    abstract public Współrzędne[] możliweRuchy(InterfejsPlanszy plansza);
    public Gracz gracz() {
        return gracz;
    }
}
