import java.util.ArrayList;

abstract public class BierkaPolowa extends Bierka {
    Współrzędne[] pola;
    public abstract Współrzędne[] polaRuchu();

    public BierkaPolowa(Gracz gracz, Współrzędne współrzędne) {
        super(gracz, współrzędne);
    }

    @Override
    public boolean czyMożnaRuszyć(InterfejsPlanszy plansza) {
        Współrzędne tymczasowe = new Współrzędne(współrzędne.pion(), współrzędne.poziom());
        for (Współrzędne k : polaRuchu()) {
            tymczasowe.zaktualizujWspółrzędne(k.pion(), k.poziom());
            if (plansza.czyZajęte(tymczasowe) == 0) {
                return true;
            }
            tymczasowe = new Współrzędne(współrzędne.pion(), współrzędne.poziom());
        }
        return false;
    }

    @Override
    public Współrzędne[] możliweRuchy(InterfejsPlanszy plansza) {
        ArrayList<Współrzędne> możliweRuchy = new ArrayList<>();
        Współrzędne tymczasowe = new Współrzędne(współrzędne.pion(), współrzędne.poziom());
        for (Współrzędne k : polaRuchu()) {
            tymczasowe.zaktualizujWspółrzędne(k.pion(), k.poziom());
            if (plansza.czyZajęte(tymczasowe) == 0 || plansza.czyPrzeciwnik(tymczasowe, gracz) == 1) {
                możliweRuchy.add(tymczasowe);
            }
            tymczasowe = new Współrzędne(współrzędne.pion(), współrzędne.poziom());
        }
        Współrzędne[] wynik = new Współrzędne[możliweRuchy.size()];
        return możliweRuchy.toArray(wynik);
    }
}
