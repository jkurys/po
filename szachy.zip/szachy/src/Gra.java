public class Gra {
    private int numerTury;
    private Plansza plansza;
    public Gra(Gracz biały, Gracz czarny) {
        numerTury = 1;
        plansza = new Plansza(biały, czarny);
    }
    public int symuluj(Gracz biały, Gracz czarny) {
        boolean czyKoniec = false;
        boolean zwycięzca = false;
        while(numerTury < 50 && czyKoniec == false) {
            String s = "Tura nr ";
            s += numerTury + ": ";
            System.out.println(s);
            czyKoniec = biały.wykonajRuch(plansza);
            System.out.println(plansza.toString());
            if (czyKoniec == false) {
                czyKoniec = czarny.wykonajRuch(plansza);
                System.out.println(plansza.toString());
            }
            else {
                zwycięzca = true;
            }
            numerTury++;
        }
        if (numerTury == 50) {
            return -1;
        }
        if (zwycięzca == true) {
            return 1;
        }
        else {
            return 0;
        }
    }
}
