public class Współrzędne {
    private int pion;
    private int poziom;
    public Współrzędne(int pion, int poziom) {
        this.pion = pion;
        this.poziom = poziom;
    }
    public int pion() {
        return pion;
    }
    public int poziom() {
        return poziom;
    }
    public void zmieńPion(int oIle) {
        pion += oIle;
    }
    public void zmieńPoziom(int oIle) {
        poziom += oIle;
    }
    public void zaktualizujWspółrzędne(int pion, int poziom) {
        this.pion = pion;
        this.poziom = poziom;
    }
}
