import java.util.ArrayList;

public class Plansza implements InterfejsPlanszy{
    private Pole[][] pola;
    private ArrayList<Bierka> bierki;
    public Plansza(Gracz biały, Gracz czarny) {
        this.pola = new Pole[8][8];
        this.bierki = new ArrayList<>();
        bierki.add(new Wieża(biały, new Współrzędne(0, 0)));
        bierki.add(new Skoczek(biały, new Współrzędne(0, 1)));
        bierki.add(new Goniec(biały, new Współrzędne(0, 2)));
        bierki.add(new Hetman(biały, new Współrzędne(0, 3)));
        bierki.add(new Król(biały, new Współrzędne(0, 4)));
        bierki.add(new Goniec(biały, new Współrzędne(0, 5)));
        bierki.add(new Skoczek(biały, new Współrzędne(0, 6)));
        bierki.add(new Wieża(biały, new Współrzędne(0, 7)));

        bierki.add(new Wieża(czarny, new Współrzędne(7, 0)));
        bierki.add(new Skoczek(czarny, new Współrzędne(7, 1)));
        bierki.add(new Goniec(czarny, new Współrzędne(7, 2)));
        bierki.add(new Hetman(czarny, new Współrzędne(7, 3)));
        bierki.add(new Król(czarny, new Współrzędne(7, 4)));
        bierki.add(new Goniec(czarny, new Współrzędne(7, 5)));
        bierki.add(new Skoczek(czarny, new Współrzędne(7, 6)));
        bierki.add(new Wieża(czarny, new Współrzędne(7, 7)));

        for (int i = 0; i < 8; i++) {
            bierki.add(new Pion(biały, new Współrzędne(1, i)));
        }

        for (int i = 0; i < 8; i++) {
            bierki.add(new Pion(czarny, new Współrzędne(6, i)));
        }

        pola[0][0] = new Pole(bierki.get(0), new Współrzędne(0, 0));
        pola[0][1] = new Pole(bierki.get(1), new Współrzędne(0, 1));
        pola[0][2] = new Pole(bierki.get(2), new Współrzędne(0, 2));
        pola[0][3] = new Pole(bierki.get(3), new Współrzędne(0, 3));
        pola[0][4] = new Pole(bierki.get(4), new Współrzędne(0, 4));
        pola[0][5] = new Pole(bierki.get(5), new Współrzędne(0, 5));
        pola[0][6] = new Pole(bierki.get(6), new Współrzędne(0, 6));
        pola[0][7] = new Pole(bierki.get(7), new Współrzędne(0, 7));

        pola[7][0] = new Pole(bierki.get(8), new Współrzędne(7, 0));
        pola[7][1] = new Pole(bierki.get(9), new Współrzędne(7, 1));
        pola[7][2] = new Pole(bierki.get(10), new Współrzędne(7, 2));
        pola[7][3] = new Pole(bierki.get(11), new Współrzędne(7, 3));
        pola[7][4] = new Pole(bierki.get(12), new Współrzędne(7, 4));
        pola[7][5] = new Pole(bierki.get(13), new Współrzędne(7, 5));
        pola[7][6] = new Pole(bierki.get(14), new Współrzędne(7, 6));
        pola[7][7] = new Pole(bierki.get(15), new Współrzędne(7, 7));

        for (int i = 0; i < 8; i++) {
            pola[1][i] = new Pole(bierki.get(16 + i), new Współrzędne(1, i));
            pola[6][i] = new Pole(bierki.get(24 + i), new Współrzędne(6, i));
        }

        for (int i = 2; i < 6; i++) {
            for (int j = 0; j < 8; j++) {
                pola[i][j] = new Pole(null, new Współrzędne(i, j));
            }
        }
    }

    @Override
    public ArrayList<Bierka> dajBierki(Gracz gracz) {
        ArrayList<Bierka> wynik = new ArrayList<>();
        for (Bierka b : bierki) {
            if (b.gracz().kolor() == gracz.kolor()) {
                wynik.add(b);
            }
        }
        return wynik;
    }

    @Override
    public boolean czyKról(Współrzędne współrzędne, Gracz gracz) {
        Bierka bierka = pola[współrzędne.pion()][współrzędne.poziom()].dajBierkę();
        String nazwa = "";
        if (bierka != null) {
            nazwa = bierka.toString();
        }
        else {
            return false;
        }
        if (gracz.kolor() == true) {
            if (nazwa.equals("k")) {
                return true;
            }
        }
        else {
            if (nazwa.equals("K")) {
                return true;
            }
        }
        return false;
    }

    @Override
    public String toString() {
        String s = "";
        for(int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                s += pola[i][j].toString();
            }
            s += "\n";
        }
        return s;
    }

    @Override
    public int czyZajęte(Współrzędne współrzędne) {
        int pion = współrzędne.pion();
        int poziom = współrzędne.poziom();
        if (pion < 0 || pion >= 8 || poziom < 0 || poziom >= 8) {
            return -1;
        }
        if (pola[pion][poziom].dajBierkę() == null) {
            return 0;
        }
        else {
            return 1;
        }
    }

    @Override
    public void zmieńPole(Bierka bierka, Współrzędne współrzędne) {
        int y = bierka.współrzędne().pion();
        int x = bierka.współrzędne().poziom();
        pola[y][x].zmieńBierkę(null);
        y = współrzędne.pion();
        x = współrzędne.poziom();
        if (pola[y][x].dajBierkę() != null) {
            for (int i = 0; i < bierki.size(); i++) {
                if (bierki.get(i) == pola[y][x].dajBierkę()) {
                    bierki.remove(i);
                    break;
                }
            }
        }
        pola[y][x].zmieńBierkę(bierka);
        bierka.współrzędne().zaktualizujWspółrzędne(współrzędne.pion(), współrzędne.poziom());
    }

    @Override
    public int czyPrzeciwnik(Współrzędne współrzędne, Gracz gracz) {
        if (czyZajęte(współrzędne) == 0) {
            return 0;
        }
        else {
            int pion = współrzędne.pion();
            int poziom = współrzędne.poziom();
            if (pion < 0 || pion >= 8 || poziom < 0 || poziom >= 8) {
                return -1;
            }
            if (pola[pion][poziom].dajBierkę() == null) {
                return 0;
            }
            if (pola[pion][poziom].dajBierkę().gracz.kolor() != gracz.kolor()) {
                return 1;
            }
            else {
                return 0;
            }
        }
    }
}
