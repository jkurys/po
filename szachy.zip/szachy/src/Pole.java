public class Pole {
    Współrzędne współrzędne;
    private Bierka bierka;
    public Pole(Bierka bierka, Współrzędne współrzędne) {
        this.bierka = bierka;
        this.współrzędne = współrzędne;
    }
    @Override
    public String toString() {
        if (bierka != null) {
            return bierka.toString();
        }
        else {
            return ".";
        }
    }
    public Bierka dajBierkę() {
        return bierka;
    }
    public void zmieńBierkę(Bierka bierka) {
        this.bierka = bierka;
    }
}
