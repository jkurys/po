public class Skoczek extends BierkaPolowa {
    public Skoczek(Gracz gracz, Współrzędne współrzędne) {
        super(gracz, współrzędne);
    }

    @Override
    public String toString() {
        if (gracz.kolor() == true) {
            return "S";
        }
        else {
            return "s";
        }
    }

    @Override
    public Współrzędne[] polaRuchu() {
        Współrzędne[] wynik = new Współrzędne[8];
        wynik[0] = new Współrzędne(współrzędne.pion() + 1, współrzędne.poziom() + 2);
        wynik[1] = new Współrzędne(współrzędne.pion() + 2, współrzędne.poziom() + 1);
        wynik[2] = new Współrzędne(współrzędne.pion() - 1, współrzędne.poziom() + 2);
        wynik[3] = new Współrzędne(współrzędne.pion() - 2, współrzędne.poziom() + 1);
        wynik[4] = new Współrzędne(współrzędne.pion() + 1, współrzędne.poziom() - 2);
        wynik[5] = new Współrzędne(współrzędne.pion() + 2, współrzędne.poziom() - 1);
        wynik[6] = new Współrzędne(współrzędne.pion() - 1, współrzędne.poziom() - 2);
        wynik[7] = new Współrzędne(współrzędne.pion() - 2, współrzędne.poziom() - 1);
        return wynik;
    }


}
