public class Goniec extends BierkaKierunkowa{
    public Goniec(Gracz gracz, Współrzędne współrzędne) {
        super(gracz, współrzędne);
    }

    @Override
    public Współrzędne[] kierunkiRuchu() {
        Współrzędne[] wynik = {new Współrzędne(1, 1), new Współrzędne(1, -1),
                new Współrzędne(-1, 1), new Współrzędne(-1, -1)};
        return wynik;
    }

    @Override
    public String toString() {
        if (gracz.kolor() == true) {
            return "G";
        }
        else {
            return "g";
        }
    }
}
