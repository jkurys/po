import java.util.Random;

public class Hetman extends BierkaKierunkowa {
    public Hetman(Gracz gracz, Współrzędne współrzędne) {
        super(gracz, współrzędne);
    }

    @Override
    public Współrzędne[] kierunkiRuchu() {
        Współrzędne[] wynik = {new Współrzędne(1, 0), new Współrzędne(1, -1),
                new Współrzędne(1, 1), new Współrzędne(0, 1),
                new Współrzędne(0, -1), new Współrzędne(-1, 1),
                new Współrzędne(-1, 0), new Współrzędne(-1, -1)};
        return wynik;
    }

    @Override
    public String toString() {
        if (gracz.kolor() == true) {
            return "H";
        }
        else {
            return "h";
        }
    }
}
