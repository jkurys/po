import java.util.ArrayList;

public interface InterfejsPlanszy {
    int czyZajęte(Współrzędne współrzędne);
    int czyPrzeciwnik(Współrzędne współrzędne, Gracz gracz);
    void zmieńPole(Bierka bierka, Współrzędne współrzędne);
    boolean czyKról(Współrzędne współrzędne, Gracz gracz);
    ArrayList<Bierka> dajBierki(Gracz gracz);
}
