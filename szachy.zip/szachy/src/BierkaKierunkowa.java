import java.util.ArrayList;

abstract public class BierkaKierunkowa extends Bierka {
    public abstract Współrzędne[] kierunkiRuchu();

    public BierkaKierunkowa(Gracz gracz, Współrzędne współrzędne) {
        super(gracz, współrzędne);
    }
    @Override
    public boolean czyMożnaRuszyć(InterfejsPlanszy plansza) {
        Współrzędne tymczasowe = new Współrzędne(współrzędne.pion(), współrzędne.poziom());
        for (Współrzędne k : kierunkiRuchu()) {
            tymczasowe.zmieńPion(k.pion());
            tymczasowe.zmieńPoziom(k.poziom());
            if (plansza.czyZajęte(tymczasowe) == 0) {
                return true;
            }
            tymczasowe = new Współrzędne(współrzędne.pion(), współrzędne.poziom());
        }
        return false;
    }

    @Override
    public Współrzędne[] możliweRuchy(InterfejsPlanszy plansza) {
        Współrzędne tymczasowe = new Współrzędne(współrzędne.pion(), współrzędne.poziom());
        ArrayList<Współrzędne> możliweRuchy = new ArrayList<>();
        for (Współrzędne k : kierunkiRuchu()) {
            tymczasowe.zmieńPion(k.pion());
            tymczasowe.zmieńPoziom(k.poziom());
            while (plansza.czyZajęte(tymczasowe) == 0 || plansza.czyPrzeciwnik(tymczasowe, gracz) == 1) {
                Współrzędne kopia = new Współrzędne(tymczasowe.pion(), tymczasowe.poziom());
                możliweRuchy.add(kopia);
                tymczasowe.zmieńPion(k.pion());
                tymczasowe.zmieńPoziom(k.poziom());
            }
            tymczasowe = new Współrzędne(współrzędne.pion(), współrzędne.poziom());
        }
        Współrzędne[] wynik = new Współrzędne[możliweRuchy.size()];
        return możliweRuchy.toArray(wynik);
    }
}
