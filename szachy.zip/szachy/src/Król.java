public class Król extends BierkaPolowa {
    public Król(Gracz gracz, Współrzędne współrzędne) {
        super(gracz, współrzędne);
    }

    @Override
    public Współrzędne[] polaRuchu() {
        int y = współrzędne.pion();
        int x = współrzędne.poziom();
        Współrzędne[] wynik = {new Współrzędne(y - 1, x), new Współrzędne(y + 1, x),
                new Współrzędne(y, x - 1), new Współrzędne(y, x + 1),
                new Współrzędne(y - 1, x - 1), new Współrzędne(y - 1, x + 1),
                new Współrzędne(y + 1, x - 1), new Współrzędne(y + 1, x + 1)};
        return wynik;
    }

    @Override
    public String toString() {
        if (gracz.kolor() == true) {
            return "K";
        }
        else {
            return "k";
        }
    }
}
