public class Main {
    public static void main(String args[]) {
        Gracz biały = new Gracz(true);
        Gracz czarny = new Gracz(false);
        Gra gra = new Gra(biały, czarny);
        int wynik = gra.symuluj(biały, czarny);
        if (wynik == 1) {
            System.out.println("Wygrał gracz biały.");
        }
        else if (wynik == 0) {
            System.out.println("Wygrał gracz czarny.");
        }
        else {
            System.out.println("Remis.");
        }
    }
}
