abstract public class Człowiek {
    String imie;
    String nazwisko;
    boolean płeć;
    Człowiek(String imie, String nazwisko, boolean płeć) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.płeć = płeć;
    }
}