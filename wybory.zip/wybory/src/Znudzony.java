import java.util.ArrayList;

public class Znudzony extends Wyborca {
    Znudzony(String imie, String nazwisko, boolean plec) {
        super(imie, nazwisko, plec);
    }
    @Override
    Kandydat dajGłos(ArrayList<Kandydat> lista) {
        return null;
    }
}