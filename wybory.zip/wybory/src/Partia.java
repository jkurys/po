public class Partia{
    String nazwa;
}
