import java.util.ArrayList;
import java.util.Random;

public class Partyjniak extends Wyborca {
    Partia ulubiona;

    Partyjniak(String imie, String nazwisko, boolean plec, Partia ulubiona) {
        super(imie, nazwisko, plec);
        this.ulubiona = ulubiona;
    }

    @Override
    Kandydat dajGłos(ArrayList<Kandydat> lista) {
        ArrayList <Kandydat> zMojejPartii = new ArrayList<Kandydat>();
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).partia == ulubiona) zMojejPartii.add(lista.get(i));
        }
        if (zMojejPartii.size() == 0) return null;
        int x = new Random().nextInt(zMojejPartii.size());
        return zMojejPartii.get(x);
    }
}