import java.util.ArrayList;

public class Feminista extends Wyborca {

    Feminista(String imie, String nazwisko, boolean plec) {
        super(imie, nazwisko, plec);
    }

    @Override
    Kandydat dajGłos(ArrayList<Kandydat> lista) {
        Kandydat wybrany = null;
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).płeć == false) {
                if (wybrany == null || wybrany.nazwisko.compareTo(lista.get(i).nazwisko) > 0)
                    wybrany = lista.get(i);
            }
        }
        return wybrany;
    }
}