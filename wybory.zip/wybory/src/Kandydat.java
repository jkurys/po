public class Kandydat extends Człowiek {
    Partia partia;
    private int liczbaGłosów = 0;
    Kandydat (String imie, String nazwisko, boolean płeć) {
        super(imie, nazwisko, płeć);
        this.partia = partia;
    }
    public void dodajGłos() {
        this.liczbaGłosów++;
    }
    public int ileGłosów() {
        return this.liczbaGłosów;
    }
}
