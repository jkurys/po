import java.util.ArrayList;

public class Wybory {
    ArrayList<Kandydat> kandydaci;
    ArrayList<Wyborca> wyborcy;
    public Wybory (Kandydat[] lista, Wyborca[] listaWyborców) {
        for (Kandydat k : lista) {
            kandydaci.add(k);
        }
        for (Wyborca w : listaWyborców) {
            wyborcy.add(w);
        }
    }
    public void przeprowadź() {
        int liczbaWażnych = 0;
        for (Wyborca w : this.wyborcy) {
            try {
                w.dajGłos(kandydaci).dodajGłos();
                liczbaWażnych++;
            }
            catch (NullPointerException e) {}
        }
        int procentWażnych = 100 * liczbaWażnych / this.wyborcy.size();
        System.out.println("Procent ważnych głosów: " + procentWażnych + "%");
        for (Kandydat k : this.kandydaci) {
            int wynik = 100 * k.ileGłosów() / liczbaWażnych;
            System.out.println(k.toString() + " Wynik: " + wynik + "%");
        }
    }
}
