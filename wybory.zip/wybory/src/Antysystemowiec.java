import java.util.ArrayList;
import java.util.Random;

public class Antysystemowiec extends Wyborca {

    Antysystemowiec(String imie, String nazwisko, boolean plec) {
        super(imie, nazwisko, plec);
    }

    @Override
    Kandydat dajGłos(ArrayList<Kandydat> lista) {
        int x = new Random().nextInt(2);
        if (x == 0) return null;
        ArrayList <Kandydat> bezpartyjni = new ArrayList<Kandydat>();
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).partia == null) bezpartyjni.add(lista.get(i));
        }
        x = new Random().nextInt(bezpartyjni.size());
        return bezpartyjni.get(x);
    }
}