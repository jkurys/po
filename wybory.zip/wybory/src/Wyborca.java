import java.util.ArrayList;

abstract class Wyborca extends Człowiek {
    Wyborca(String imie, String nazwisko, boolean plec) {
        super(imie, nazwisko, plec);
    }
    abstract Kandydat dajGłos(ArrayList<Kandydat> lista);
}